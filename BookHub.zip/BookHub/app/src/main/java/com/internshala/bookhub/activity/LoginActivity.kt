package com.internshala.bookhub.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.internshala.bookhub.R

class LoginActivity : AppCompatActivity() {

    lateinit var username:EditText
    lateinit var password:EditText
    lateinit var btnlogin:Button
    val validUsername="123456"
    val validPassword="mohit"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        username=findViewById(R.id.username)
        password=findViewById(R.id.password)
        btnlogin=findViewById(R.id.btnlogin)


        btnlogin.setOnClickListener {

            val password=password.text.toString()
            val username=username.text.toString()

            if((username==validUsername) && (password==validPassword )){
                val intent= Intent(this@LoginActivity,MainActivity::class.java)
                startActivity(intent)
            }
            else {
                Toast.makeText(this@LoginActivity, "invalid username or password", Toast.LENGTH_SHORT).show()
            }


        }




    }
}
