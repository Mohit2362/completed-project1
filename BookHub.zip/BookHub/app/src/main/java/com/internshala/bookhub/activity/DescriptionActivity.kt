package com.internshala.bookhub.activity

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.internshala.bookhub.R
import com.squareup.picasso.Picasso
import org.json.JSONObject
import java.lang.Exception
import android.content.Context
import android.content.Intent
import android.os.AsyncTask
import android.provider.Settings
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.internshala.bookhub.database.BookDatabase
import com.internshala.bookhub.database.BookEntity
import com.internshala.bookhub.util.ConnectionManager

class DescriptionActivity : AppCompatActivity() {

    lateinit var txtBookName: TextView
    lateinit var txtBookAuthor:TextView
    lateinit var price:TextView
    lateinit var rating:TextView
    lateinit var imgBookImage:ImageView
    lateinit var description:TextView
    lateinit var addtofav:Button
    lateinit var progressLayout:RelativeLayout
    lateinit var progressBar:ProgressBar
    lateinit var toolbar: Toolbar

    var bookId:String?="100"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)

        txtBookAuthor=findViewById(R.id.txtBookAuthor)
        txtBookName=findViewById(R.id.txtBookName)
        price=findViewById(R.id.price)
        rating=findViewById(R.id.rating)
        imgBookImage=findViewById(R.id.imgBookImage)
        description=findViewById(R.id.description)
        addtofav=findViewById(R.id.addtofav)
        progressBar=findViewById(R.id.progressBar)
        progressBar.visibility= View.VISIBLE
        progressLayout=findViewById(R.id.progressLayout)
        progressLayout.visibility=View.VISIBLE
        toolbar=findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.title="Book Details"

        if(intent!=null){
            bookId=intent.getStringExtra("book_id")
        }
        else{
            finish()
            Toast.makeText(this@DescriptionActivity,"error",Toast.LENGTH_SHORT).show()
        }
        if(bookId=="100"){
            finish()
            Toast.makeText(this@DescriptionActivity,"error occured",Toast.LENGTH_SHORT).show()
        }

       val queue= Volley.newRequestQueue(this@DescriptionActivity)
        val url="http://13.235.250.119/v1/book/get_book/"
        val jsonParams=JSONObject()
          jsonParams.put("book_id",bookId)
       if (ConnectionManager().checkConnectivity(this@DescriptionActivity)) {
           val jsonRequest =
               object : JsonObjectRequest(Request.Method.POST, url, jsonParams, Response.Listener {
                   try {
                       val success = it.getBoolean("success")


                       if (success) {
                           val bookJsonObject = it.getJSONObject("book_data")
                           progressLayout.visibility = View.GONE

                           val bookImageUrl = bookJsonObject.getString("image")

                           Picasso.get().load(bookJsonObject.getString("image"))
                               .error(R.drawable.captain_america).into(imgBookImage)
                           txtBookName.text = bookJsonObject.getString("name")
                           txtBookAuthor.text = bookJsonObject.getString("author")
                           price.text = bookJsonObject.getString("price")
                           rating.text = bookJsonObject.getString("rating")
                           description.text = bookJsonObject.getString("description")

                           val bookEntity = BookEntity(

                               bookId?.toInt() as Int,
                               txtBookName.text.toString(),
                               txtBookAuthor.text.toString(),
                               price.text.toString(),
                               rating.text.toString(),
                               description.text.toString(),
                               bookImageUrl

                           )
                           val checkFav = DBAsyncTask(applicationContext, bookEntity, 1).execute()
                           val isFav = checkFav.get()

                           if (isFav) {
                               addtofav.text = "Remove from favourites"
                               val favColor = ContextCompat.getColor(
                                   applicationContext,
                                   R.color.colorFAvourite
                               )
                               addtofav.setBackgroundColor(favColor)
                           } else {
                               addtofav.text = "Add to Favourites"
                               val noFavColor =
                                   ContextCompat.getColor(applicationContext, R.color.colorPrimary)
                               addtofav.setBackgroundColor(noFavColor)

                           }

                           addtofav.setOnClickListener {
                               if (!DBAsyncTask(applicationContext, bookEntity, 1).execute()
                                       .get()
                               ) {

                                   val async =
                                       DBAsyncTask(applicationContext, bookEntity, 2).execute()
                                   val result = async.get()
                                   if (result) {

                                       Toast.makeText(
                                           this@DescriptionActivity,
                                           "Added to Favourites",
                                           Toast.LENGTH_SHORT
                                       ).show()

                                       addtofav.text = "Remove from Favourites"
                                       val favColor = ContextCompat.getColor(
                                           applicationContext,
                                           R.color.colorFAvourite
                                       )
                                       addtofav.setBackgroundColor(favColor)
                                   }
                                   else{
                                       Toast.makeText(this@DescriptionActivity,"Error",Toast.LENGTH_SHORT).show()
                                   }

                               }
                               else{

                                   val async=DBAsyncTask(applicationContext,bookEntity,3).execute()
                                   val result=async.get()
                                   if(result){
                                       Toast.makeText(this@DescriptionActivity,"Removed from Favourites",Toast.LENGTH_SHORT).show()
                                       addtofav.text="Add to Favourites"
                                       val noFav=ContextCompat.getColor(applicationContext,R.color.colorPrimary)
                                       addtofav.setBackgroundColor(noFav)

                                   }
                                   else{
                                       Toast.makeText(this@DescriptionActivity,"Error occured",Toast.LENGTH_SHORT).show()

                                   }

                               }
                           }
                       }
                           else {

                                   Toast.makeText(
                                       this@DescriptionActivity,
                                       "Some error occured",
                                       Toast.LENGTH_SHORT
                                   ).show()
                               }
                           }

                   catch (e: Exception) {
                       Toast.makeText(
                           this@DescriptionActivity,
                           "unexpected error occured",
                           Toast.LENGTH_SHORT
                       ).show()
                   }

               }, Response.ErrorListener {
                   Toast.makeText(this@DescriptionActivity, "volley error $it", Toast.LENGTH_SHORT).show()

               }) {
                   override fun getHeaders(): MutableMap<String, String> {
                       val headers = HashMap<String, String>()
                       headers["Content-type"] = "application/json"
                       headers["token"] = "98c275f06382ae"
                       return headers
                   }
               }
           queue.add(jsonRequest)
       }
        else{
           val dialog= AlertDialog.Builder(this@DescriptionActivity)
           dialog.setTitle("error")
           dialog.setMessage("Connection not found")
           dialog.setPositiveButton("open setting"){text,listener->
               val settingsIntent= Intent(Settings.ACTION_WIRELESS_SETTINGS)
               startActivity(settingsIntent)
               finish()

           }
           dialog.setNegativeButton("Exit"){text,listener->
               ActivityCompat.finishAffinity(this@DescriptionActivity)
           }
           dialog.create()
           dialog.show()
       }


    }



    class DBAsyncTask(context: Context,val bookEntity: BookEntity,val mode:Int):AsyncTask<Void,Void,Boolean>() {

        /*
        Mode 1->Check DB if the book is favourite or not
        Mode 2-> SAve the book in the favorite
        Mode-> REmove the favourite book
         */

        val db=Room.databaseBuilder(context,BookDatabase::class.java,"books-db").build()

        override fun doInBackground(vararg params: Void?): Boolean {

            when(mode){
                1->{
                    //Check DB if the book is favourite or not
                    val book:BookEntity?=db.bookDao().getBookById(bookEntity.book_id.toString())
                    db.close()
                    return book!=null


                }

                2->{
                    //SAve the book into favourites

                    db.bookDao().insertBook(bookEntity )
                    db.close()
                    return true


                }

                3->{
                    //remove the book from favourites

                    db.bookDao().deleteBook(bookEntity)
                    db.close()
                    return true

                }
            }
            return false
        }
    }
}
